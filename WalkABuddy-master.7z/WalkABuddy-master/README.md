# WalkABuddy
This is just the entry of the app i want to create
momentarly the app has a login, signin , reset password form.
if the registration is successfull it will direct the user to
the maps activity, it will ask for the gps permission and then
it will pin point the user's location , if the gps is absent 
it will put the marker in the location that i have decided, which 
is Tirana, in Albania
-the actual version had the Google Maps API, is connected to firebase for 
the authentication

- further implementation

-- start,stop button with the implementation of calculating distance and time

-- reports in which it will show previous walks and times (to implement with firebase)

-- navigation view

-- icons for track

-- goggle authentication for the sign in (momentarily is present only the button but not the function behind)
